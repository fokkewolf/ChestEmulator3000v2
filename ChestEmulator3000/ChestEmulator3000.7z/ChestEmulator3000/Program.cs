﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChestEmulator3000
{
    public enum EnumGrade
    {
        Common = 1,
        Rare = 2,
        Epic = 3,
        Legendary = 4,
        Bullshit = 5
    }

    public abstract class ChestModel
    {
        protected Random _rnd;
        protected int itemsToGive;
        public List<ChestItemModel> Items { get; set; }

        protected void resetRandom()
        {
            _rnd = new Random(Guid.NewGuid().GetHashCode());
        }
        public virtual ChestItemModel RollOne()
        {
            resetRandom();
            var n = this.Items.Count();
            var i = _rnd.Next(0, n);
            return this.Items[i];
        }
        public virtual List<ChestItemModel> RollAll()
        {
            resetRandom();
            List<ChestItemModel> result = new List<ChestItemModel>();
            for (int i = 0; i < itemsToGive; i++)
            {
                var card = this.Items[_rnd.Next(0, this.Items.Count - 1)];
                result.Add(card);
            }
            return result;
        }
    }
    public class QualityChest : ChestModel
    {
        public QualityChest(Dictionary<EnumGrade, int> gradeCounts)
        {
            this.itemsToGive = 1;
            this.Items = new List<ChestItemModel>();
            int id = 0;
            foreach (var grc in gradeCounts)
            {
                for (int i = 0; i < grc.Value; i++)
                {
                    this.Items.Add(new ChestItemModel(grc.Key, id));
                }
            }
        }
    }
    public class RadiantChestModel : ChestModel
    {
        bool boosted { get; set; }
        bool cardUniquePerChest { get; set; }
        public ChestModel qualityChest { get; set; }

        public EnumGrade GetQuality()
        {
            return qualityChest.RollOne().Grade;
        }

        public Dictionary<EnumGrade, List<ChestItemModel>> groupedCards;
        public RadiantChestModel(List<ChestItemModel> items, Dictionary<EnumGrade, int> gradeCounts, bool boosted = false, bool cardUniquePerChest = true)
        {
            this.itemsToGive = boosted ? 4 : 3;
            this.Items = items;
            this.groupedCards = items.GroupBy(x => x.Grade)
                .ToDictionary(x => x.Key, x => x.ToList());
            this.qualityChest = new QualityChest(gradeCounts);
            this.cardUniquePerChest = cardUniquePerChest;
        }

        public override List<ChestItemModel> RollAll()
        {
            resetRandom();
            List<ChestItemModel> result = new List<ChestItemModel>();
            for (int i = 0; i < itemsToGive; i++)
            {
                bool unique = false;
                do
                {
                    var grade = GetQuality();
                    var itemPool = groupedCards[grade];
                    var card = itemPool[_rnd.Next(0, itemPool.Count - 1)];
                    unique = !result.Any(x => x.Name == card.Name);
                    if (unique)
                    {
                        result.Add(card);
                    }
                } while (!unique && cardUniquePerChest);
            }
            return result;
        }
    }

    public class ChestItemModel
    {
        public EnumGrade Grade { get; set; }
        public string Name { get; set; }

        public bool Wanted { get; set; }
        public ChestItemModel(EnumGrade grade, int i, bool wanted = true, string cardNameOptional = "")
        {
            this.Grade = grade;
            this.Name = String.Format("{0}_{1}_{2}", grade.ToString(), cardNameOptional, i.ToString());
            this.Wanted = wanted;
        }
    }

    public class PersonCardModel : ChestItemModel
    {
        public int InitialLevel { get; set; }
        public int Level { get; set; }
        public int CurrentDupes { get; set; }
        public PersonCardModel(
            int initLevel,
            EnumGrade grade, int i, bool wanted = true, string cardNameOptional = "") : base(grade, i, wanted, cardNameOptional)
        {
            InitialLevel = initLevel;
            Level = initLevel;
            CurrentDupes = 0;
        }
        public int GetDupesToLvlUp()
        {
            switch (Level)
            {
                case 1:
                    switch (Grade)
                    {
                        case EnumGrade.Common:
                            return 6;
                        case EnumGrade.Rare:
                            return 4;
                        case EnumGrade.Epic:
                            return 2;
                        case EnumGrade.Legendary:
                            return 1;
                        default: return 0;
                    }
                    break;
                case 2:
                    switch (Grade)
                    {
                        case EnumGrade.Common:
                            return 9;
                        case EnumGrade.Rare:
                            return 6;
                        case EnumGrade.Epic:
                            return 3;
                        case EnumGrade.Legendary:
                            return 2;
                        default: return 0;
                    }
                    break;
                case 3:
                    switch (Grade)
                    {
                        case EnumGrade.Common:
                            return 12;
                        case EnumGrade.Rare:
                            return 8;
                        case EnumGrade.Epic:
                            return 4;
                        case EnumGrade.Legendary:
                            return 3;
                        default: return 0;
                    }
                case 4:
                    switch (Grade)
                    {
                        case EnumGrade.Common:
                            return 16;
                        case EnumGrade.Rare:
                            return 10;
                        case EnumGrade.Epic:
                            return 5;
                        case EnumGrade.Legendary:
                            return 4;
                        default: return 0;
                    }
                default: return 0;
            }
        }
        public void ApplyDupe()
        {
            CurrentDupes++;
            if (CurrentDupes == GetDupesToLvlUp())
            {
                LvlUp();
            }
        }
        public void LvlUp()
        {
            CurrentDupes++;
            if (Level == 5) return;
            Level++;
            CurrentDupes = 0;
        }
        public void Reset()
        {
            Level = InitialLevel;
            CurrentDupes = 0;
        }
    }
    class Program
    {
        static int commonCountPerChar = 8;
        static int rareCountPerChar = 5;
        static int epicCountPerChar = 3;
        static int legendaryCountPerChar = 4;

        static int CharCount = 34;

        static bool alg()
        {
            bool succ = false;
            Console.WriteLine("StartingLevel: ");
            int startingLevel = 1;
            while (!succ) {
                succ = Int32.TryParse(Console.ReadLine(), out startingLevel);
            }
            succ = false;
            Console.WriteLine("DesiredLevel: ");
            int desiredLevel = 5;
            while (!succ)
            {
                succ = Int32.TryParse(Console.ReadLine(), out desiredLevel);
            }
            succ = false;
            Console.WriteLine("AttemptsCount: ");
            int attemptCount = 100;
            while (!succ)
            {
                succ = Int32.TryParse(Console.ReadLine(), out attemptCount);
            }
            succ = false;
            Console.WriteLine("CardUniquePerChest: ");
            bool cardUniquePerChest = false;
            while (!succ)
            {
                succ = Boolean.TryParse(Console.ReadLine(), out cardUniquePerChest);
            }

            //For convenience so that we don't need to delve into chest filling code to affect quantities
            var commonCount = commonCountPerChar * CharCount;
            var rareCount = rareCountPerChar * CharCount;
            var epicCount = epicCountPerChar * CharCount;
            var legendaryCount = legendaryCountPerChar * CharCount;

            #region Fill Chest
            //Indexers used to make something like a unique card ID
            var iCommon = 0;
            var iRare = 0;
            var iEpic = 0;
            var iLegendary = 0;

            List<PersonCardModel> personWantedCards = new List<PersonCardModel>();
            List<ChestItemModel> RadiantChestItems = new List<ChestItemModel>();
            do
            {
                bool wanted = false;
                if (iRare < rareCount)
                {
                    iRare++;
                    wanted = iRare <= rareCountPerChar;
                    RadiantChestItems.Add(new ChestItemModel(EnumGrade.Rare, iRare, false, wanted ? "Ash" : ""));
                    if (wanted)
                    {
                        personWantedCards.Add(new PersonCardModel(startingLevel, EnumGrade.Rare, iRare, true, "Ash"));
                    }
                }
                if (iEpic < epicCount)
                {
                    iEpic++;
                    wanted = iEpic <= epicCountPerChar;
                    RadiantChestItems.Add(new ChestItemModel(EnumGrade.Epic, iEpic, false, wanted ? "Ash" : ""));
                    if (wanted)
                    {
                        personWantedCards.Add(new PersonCardModel(startingLevel, EnumGrade.Epic, iEpic, true, "Ash"));
                    }
                }
                if (iLegendary < legendaryCount)
                {
                    iLegendary++;
                    wanted = iLegendary <= legendaryCountPerChar;
                    RadiantChestItems.Add(new ChestItemModel(EnumGrade.Legendary, iLegendary, false, wanted ? "Ash" : ""));
                    if (wanted)
                    {
                        personWantedCards.Add(new PersonCardModel(startingLevel, EnumGrade.Legendary, iLegendary, true, "Ash"));
                    }
                }

                iCommon++;
                wanted = iCommon <= commonCountPerChar;
                RadiantChestItems.Add(new ChestItemModel(EnumGrade.Common, iCommon, false, wanted ? "Ash" : ""));
                if (wanted)
                {
                    personWantedCards.Add(new PersonCardModel(startingLevel, EnumGrade.Common, iCommon, true, "Ash"));
                }
            } while (iCommon != commonCount);

            //At this point I assume radiant chest has an amount of skins / voicepacks and shit equal to the count of cards.
            var totalCards = RadiantChestItems.Count();
            for (int i = 1; i <= totalCards; i++)
            {
                RadiantChestItems.Add(new ChestItemModel(EnumGrade.Bullshit, i, false));
            }
            #endregion

            #region quality randomizator config
            //This works this way: I assume each chest has 100 items, 
            Dictionary<EnumGrade, int> gradeCounts = new Dictionary<EnumGrade, int>();

            gradeCounts.Add(EnumGrade.Common, 162);
            gradeCounts.Add(EnumGrade.Rare, 95);
            gradeCounts.Add(EnumGrade.Epic, 58);
            gradeCounts.Add(EnumGrade.Legendary, 10);
            gradeCounts.Add(EnumGrade.Bullshit, 43);
            #endregion

            ChestModel chest = new RadiantChestModel(RadiantChestItems, gradeCounts, true, cardUniquePerChest);

            //this to get the card to lvl up easy in case we're finally lucky
            var personWantedCardsDictionary = personWantedCards.ToDictionary(x => x.Name, x => x);


            int totalChests = 0;
            #region Opening chests
            //Duh
            for (int i = 0; i < attemptCount; i++)
            {
                int chestCount = 0;
                int fuckingHell = 0;
                //Open chests until all desired cards are open
                while (!personWantedCards.All(c => c.Level >= desiredLevel))
                {
                    var fuck = chest.RollAll();
                    chestCount++;
                    //Check received stuff, see if any good dupes
                    fuck.ForEach(f =>
                    {
                        if (!personWantedCardsDictionary.ContainsKey(f.Name))
                        {
                            fuckingHell++;
                        }
                        else
                        {
                            //Wooooo fucking hooo!
                            var personCard = personWantedCardsDictionary[f.Name];
                            personCard.ApplyDupe();
                        }
                    });
                }

                totalChests += chestCount;
                Console.WriteLine(String.Format("Attempt {0}, ChestCount {1}, Unnecessary Dupes = {2}", i, chestCount, fuckingHell));
                personWantedCards.ForEach(c => c.Reset());
            }
            #endregion

            var avgChestsNeeded = totalChests / attemptCount;
            Console.WriteLine(String.Format("Average Chests Needed - {0}", avgChestsNeeded));

            Console.WriteLine("Again? y/n");
            var againChar = Console.ReadKey().KeyChar;
            while (againChar != 'y' && againChar != 'Y' && againChar != 'n' && againChar != 'N')
            {
                Console.WriteLine("\ny/n!");
                againChar = Console.ReadKey().KeyChar;
            }
            
            var again = againChar == 'y' || againChar == 'Y';
            return again;
        }

        static void Main(string[] args)
        {
            while (alg())
            {
                Console.WriteLine("\n");
            }
        }
    }
}
